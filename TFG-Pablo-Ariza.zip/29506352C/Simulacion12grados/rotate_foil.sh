#!/bin/bash
ANGLE=$1
TARGET="constant/triSurface/NACA0012.stl"
OUTPUT="constant/triSurface/NACA0012_rot.stl"

if [ -z "$ANGLE" ]; then
    echo "Uso: ./rotate_foil.sh <angulo>"
    exit 1
fi

echo "Rotando NACA0012 usando rollPitchYaw..."

# Usamos rollPitchYaw: (X Y Z) en grados
# Rotamos 0 en X, 0 en Y y el ANGLE en Z
surfaceTransformPoints -rollPitchYaw "(0 0 $ANGLE)" "$TARGET" "$OUTPUT"

if [ $? -eq 0 ]; then
    echo "Exito: Archivo creado en $OUTPUT"
else
    echo "Error en la transformacion."
fi
