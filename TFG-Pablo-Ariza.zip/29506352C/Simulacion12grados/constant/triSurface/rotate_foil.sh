#!/bin/bash

# ==============================================================================
# Script para rotar NACA0012.stl en el eje Z
# Uso: ./rotate_wing.sh <angulo_grados>
# ==============================================================================

# 1. Parámetros de entrada
ANGLE=$1
AXIS="(0 0 1)"
TARGET_NAME="NACA0012.stl"
STL_DIR="constant/triSurface"

# Verificar si se proporcionó el ángulo
if [ -z "$ANGLE" ]; then
    echo "Error: Indica el ángulo. Ejemplo: ./rotate_wing.sh 5"
    exit 1
fi

# 2. Verificar si el archivo existe
if [ ! -f "$STL_DIR/$TARGET_NAME" ]; then
    echo "Error: No se encuentra el archivo $STL_DIR/$TARGET_NAME"
    echo "Asegúrate de estar en la carpeta raíz del caso de OpenFOAM."
    exit 1
fi

# 3. Definir nombre de salida
OUTPUT_FILE="$STL_DIR/NACA0012.stl"

echo "------------------------------------------------------------"
echo "Archivo detectado: $TARGET_NAME"
echo "Rotando $ANGLE grados sobre el eje Z $AXIS..."

# 4. Ejecutar la transformación
# surfaceTransformPoints es la herramienta oficial de OpenFOAM
surfaceTransformPoints -rotate "( $AXIS $ANGLE )" "$STL_DIR/$TARGET_NAME" "$OUTPUT_FILE"

if [ $? -eq 0 ]; then
    echo "ÉXITO: Creado $OUTPUT_FILE"
    echo "------------------------------------------------------------"
else
    echo "Error: Falló la transformación. ¿Tienes cargado OpenFOAM?"
    exit 1
fi
