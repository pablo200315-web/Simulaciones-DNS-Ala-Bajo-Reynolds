%Script para representar los coeficientes aerodinamicos obtenido de las simulaciones
clear;
close all;
clc;
%Se cargan los datos
data1000 = importdata('fuerzas0grados1000.dat');
data5000 = importdata('fuerzas0grados5000.dat');

raw_data1000 = data1000.data;
raw_data5000 = data5000.data;


%Se cargan las columnas con los respectivos coeficientes
time1000 = raw_data1000(:, 1);
Cd1000 = 2*raw_data1000(:, 2)/(1.225*1*1^2);
Cl1000 = 2*raw_data1000(:, 3)/(1.225*1*1^2);
time5000 = raw_data5000(:, 1);
Cd5000 = 2*raw_data5000(:, 2)/(1.225*1*1^2);
Cl5000 = 2*raw_data5000(:, 3)/(1.225*1*1^2);


%Se establece el tiempo para calcular el promedio
t_inicio = 7;
indices_estables1000 = find(time1000 >= t_inicio);
indices_estables5000 = find(time5000 >= t_inicio);

Cd_medio1000 = mean(Cd1000(indices_estables1000));
Cl_medio1000 = mean(Cl1000(indices_estables1000));
Cd_medio5000 = mean(Cd5000(indices_estables5000));
Cl_medio5000 = mean(Cl5000(indices_estables5000));

%Se representa los coeficientes
figure('Color', 'w');
hold on;
subplot(2,1,1);
d1 = plot(time1000, Cl1000, 'b', 'LineWidth', 1.5); hold on;
d1m = yline(Cl_medio1000, 'r--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

d2 = plot(time5000, Cl5000, 'g', 'LineWidth', 1.5); hold on;
d2m = yline(Cl_medio5000, 'c--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

legend ([d1, d1m, d2, d2m], {'Cl Re 1000', 'Cl Medio Re 1000', 'Cl Re 5000', 'Cl Medio Re 5000'}, 'Location', 'best');
title('Evolucion Temporal del Coeficiente de Sustentacion (Cl)');
xlabel('Tiempo (s)', 'Fontsize', 15);
ylabel ('Cl', 'Fontsize', 15); 
grid on;

subplot(2,1,2);
f1 = plot(time1000, Cd1000, 'k', 'LineWidth', 1.5); hold on;
f1m = yline(Cd_medio1000, 'r--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

f2 = plot(time5000, Cd5000, 'g', 'LineWidth', 1.5); hold on;
f2m = yline(Cd_medio5000, 'b--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

legend ([f1, f1m, f2, f2m], {'Cd Re 1000', 'Cd Medio Re 1000', 'Cd Re 5000', 'Cd Medio Re 5000'}, 'Location', 'best');

title('Evolucion Temporal del Coeficiente de Resistencia (Cd)');
xlabel('Tiempo (s)', 'Fontsize', 15);
ylabel ('Cd', 'Fontsize', 15); grid on;

fprintf('Resultados promediados desde t = %.1f s:\n', t_inicio);
fprintf('Cl medio Re 1000: %.4f\n', Cl_medio1000);
fprintf('Cd medio Re 1000: %.4f\n', Cd_medio1000);
fprintf('Cl medio Re 5000: %.4f\n', Cl_medio5000);
fprintf('Cd medio Re 5000: %.4f\n', Cd_medio5000);



%Analisis del valor estacionario

segundos_objetivo = 0:17; %Crea el vector de segundos quitando el 0

indices_enteros1000 = [];
indices_enteros5000 = [];

for s1000 = segundos_objetivo

    [val1000, idx1000] = min(abs(time1000 - s1000));

    if val1000 < 0.05
        indices_enteros1000 = [indices_enteros1000; idx1000];
    end
end

for s5000 = segundos_objetivo

    [val5000, idx5000] = min(abs(time5000 - s5000));

    if val5000 < 0.05
        indices_enteros5000 = [indices_enteros5000; idx5000];
    end
end

tiempo_filtrado = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10; 11; 12; 13; 14; 15; 16; 17];

t1000 = 0;
indices_enteros1000 = [];

for i = 1:length(time1000)

    if t1000 == 0
        if time1000(i) >= 1.0
            t1000 = 1;
            indices_enteros1000 = [indices_enteros1000; i];
        end
    else


        if time1000(i) >= (t1000 + 1) && t1000 <=17
            t1000 = t1000 + 1;
            indices_enteros1000 = [indices_enteros1000; i];
        end
    end
end

t5000 = 0;
indices_enteros5000 = [];

for j = 1:length(time5000)

    if t5000 == 0
        if time5000(j) >= 1.0
            t5000 = 1;
            indices_enteros5000 = [indices_enteros5000; j];
        end
    else


        if time5000(j) >= (t5000 + 1) && t5000 <=17
            t5000 = t5000 + 1;
            indices_enteros5000 = [indices_enteros5000; j];
        end
    end
end


Cd_filtrado1000   = Cd1000(indices_enteros1000);
Cl_filtrado1000   = Cl1000(indices_enteros1000);

Cd_filtrado5000   = Cd5000(indices_enteros5000);
Cl_filtrado5000   = Cl5000(indices_enteros5000);

%Se representa los coeficientes
figure('Color', 'w', 'Name', 'Validacion de Puntos Enteros');
hold on;

a1 = plot(tiempo_filtrado, Cl_filtrado1000, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
a2 = plot(tiempo_filtrado, Cl_filtrado5000, 'cx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
legend ([a1, a2], {'Cl Re 1000', 'Cl Re 5000'}, 'Location', 'best');

title('Coeficiente de Sustentacion (C_l) cada segundo');
xlabel('Tiempo (s)', 'Fontsize', 15.5);
ylabel ('C_l', 'Fontsize', 15.5);
grid on;

figure('Color', 'w', 'Name', 'Validacion de Puntos EnterosCd');
hold on;

b1 = plot(tiempo_filtrado, Cd_filtrado1000, 'kx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
b2 = plot(tiempo_filtrado, Cd_filtrado5000, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
legend ([b1, b2], {'Cd Re 1000', 'Cd Re 5000'}, 'Location', 'best');

title('Coeficiente de Resistencia (C_d) cada segundo');
xlabel('Tiempo (s)', 'Fontsize', 15.5);
ylabel ('C_d', 'Fontsize', 15.5);
grid on;
