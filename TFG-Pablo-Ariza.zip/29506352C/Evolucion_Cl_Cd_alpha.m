%En este archivo se representará los coeficientes respecto al ángulo de
%ataque
clear;
close all;
clc;
%Se introducen los datos

alpha = [0, 5, 8, 12, 14, 18, 24];
Cl = [0, 0.249052896, 0.324242, 0.4487, 0.5996, 0.87674905, 1.124455383];
Cd = [0.121202505, 0.12921934, 0.142234, 0.1865, 0.2408, 0.393740045, 0.63597398];
Cm = -[0, -0.0097, -0.0142, 0.0020, 0.0279, 0.1189, 0.2383];


alpha_rad = deg2rad(alpha);
Cl_teorico = 2 * pi *alpha_rad;

fig = figure('Name', 'Coeficiente Aerodinámico vs Ángulo de ataque', 'Color', 'w', 'Position', [100 100 900 400]);
hold on;
subplot(1,2,1);
d1 = plot(alpha, Cl, '-o','Color', [0 0 0], 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', [0 0.4470 0.7410]); hold on;
%d_teorica = plot(alpha, Cl_teorico, '--r','LineWidth', 2); hold on;

set(gca, 'Fontsize', 13);

ylim([0, 1.2]);

legend ([d1], {'Cl (Simulación)'}, 'Location', 'best');
title('Sustentación vs Ángulo de ataque');
xlabel('\alpha (º)', 'Fontsize', 15);
ylabel ('Coeficiente de sustentación (Cl)', 'Fontsize', 15); 
grid on;
box on;

%yline(0, 'k-', 'LineWidth', 0.5)
%xline(0, 'k-', 'LineWidth', 0.5)

subplot(1,2,2);
f1 = plot(alpha, Cd, '-o','Color', [0 0 0], 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', [0.8500 0.3250 0.0980]); hold on;
set(gca, 'Fontsize', 13);

legend ([f1], {'Cd'}, 'Location', 'best');
title('Resistencia vs Ángulo de ataque');
xlabel('\alpha (º)', 'Fontsize', 15);
ylabel ('Coeficiente de resistencia (Cd)', 'Fontsize', 15); 
grid on;
box on;

%Representacion coeficiente de cabeceo
fig = figure('Name', 'Coeficiente de momento de cabeceo vs \alpha', 'Color', 'w', 'Position', [100 100 900 400]);

h1 = plot(alpha, Cm, '-o','Color', [0 0 0], 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', [0.8500 0.3250 0.0980]); hold on;
set(gca, 'Fontsize', 13);

legend ([h1], {'Cm'}, 'Location', 'best');
title('Coeficiente de momento de cabeceo vs Ángulo de ataque');
xlabel('\alpha (º)', 'Fontsize', 15);
ylabel ('Coeficiente de momento de cabeceo (Cm)', 'Fontsize', 15); 
grid on;
box on;

%xline(0, 'k-', 'LineWidth', 0.5)

fig = figure('Name', 'Polar del perfil (Cl/Cd)', 'Color', 'w', 'Position', [100 100 900 400]);
hold on;

b1 = plot(Cd, Cl, '-o','Color', [0 0 0], 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', [0 0.4470 0.7410]); 
hold on;
set(gca, 'Fontsize', 13);
title('Coeficiente de sustentación vs Coeficiente de resistencia');
xlabel('Coeficiente de resistencia (Cd)', 'Fontsize', 15);
ylabel ('Coeficiente de sustentación (Cl)', 'Fontsize', 15); 
grid on;
box on;

alpha_fine = min(alpha):0.1:max(alpha);

Cl_fine = interp1(alpha, Cl, alpha_fine, 'pchip');
Cd_fine = interp1(alpha, Cd, alpha_fine, 'pchip');

%coeficiente = polyfit(X, Cd_fine, 1);

Cd0 = Cd(1);
k = (Cd(4)-Cd(1))/Cl(4)^2;

Cd_teorico = Cd(1) + k.*Cl.^2;

fprintf('El valor de Cd0 es: %.4f\n', Cd0);
fprintf('El valor de k es: %.4f\n', k);

fig = figure('Name', 'Polar del perfil Interpolada (Cl/Cd)', 'Color', 'w', 'Position', [100 100 900 400]);
hold on;

k1 = plot(Cd, Cl, '-o','Color', [0 0 0], 'LineWidth', 2, 'MarkerSize', 6, 'MarkerFaceColor', [0 0.4470 0.7410]); 
hold on;
set(gca, 'Fontsize', 13);
title('Coeficiente de sustentación vs Coeficiente de resistencia (Interpolados)');
xlabel('Coeficiente de resistencia Interpolados (C_D)', 'Fontsize', 15);
ylabel ('Coeficiente de sustentación Interpolados (C_L)', 'Fontsize', 15); 
grid on;
box on;

k2 = plot(Cd_teorico, Cl, '--r', 'Linewidth', 2);

set(gca, 'Fontsize', 13);
title('Coeficiente de sustentación vs Coeficiente de resistencia ');
xlabel('Coeficiente de resistencia (C_D)', 'Fontsize', 15);
ylabel('Coeficiente de sustentación (C_L)', 'Fontsize', 15);
grid on;
box on;

% RECOMENDACIÓN: Añade una leyenda para diferenciar los datos del ajuste
legend([k1, k2], {'Simulación (OpenFOAM)', 'Ajuste: C_D = C_{D,0} + k·C_L^2'}, 'Location', 'SouthEast', 'Fontsize', 11);



