%Script para representar los coeficientes aerodinamicos obtenido de las simulaciones
clear;
close all;
clc;
%Se cargan los datos
data = importdata('force.dat');
data2 = importdata('force2.dat');
data3 = importdata('force3.dat');
raw_data = data.data;
raw_data2 = data2.data;
raw_data3 = data3.data;

%Se cargan las columnas con los respectivos coeficientes
time1 = raw_data(:, 1);
Cd1 = 2*raw_data(:, 2)/(1.225*1*1^2);
Cl1 = 2*raw_data(:, 3)/(1.225*1*1^2);
time2 = raw_data2(:, 1);
Cd2 = 2*raw_data2(:, 2)/(1.225*1*1^2);
Cl2 = 2*raw_data2(:, 3)/(1.225*1*1^2);
time3 = raw_data3(:, 1);
Cd3 = 2*raw_data3(:, 2)/(1.225*1*1^2);
Cl3 = 2*raw_data3(:, 3)/(1.225*1*1^2);

%Se establece el tiempo para calcular el promedio
t_inicio = 7;
indices_estables = find(time1 >= t_inicio);
indices_estables2 = find(time2 >= t_inicio);
indices_estables3 = find(time3 >= t_inicio);

Cd_medio = mean(Cd1(indices_estables));
Cl_medio = mean(Cl1(indices_estables));
Cd_medio2 = mean(Cd2(indices_estables2));
Cl_medio2 = mean(Cl2(indices_estables2));
Cd_medio3 = mean(Cd3(indices_estables3));
Cl_medio3 = mean(Cl3(indices_estables3));

%Se representa los coeficientes
figure('Color', 'w');
hold on;
subplot(2,1,1);
d1 = plot(time1, Cl1, 'b', 'LineWidth', 1.5); hold on;
d1m = yline(Cl_medio, 'r--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

d2 = plot(time2, Cl2, 'g', 'LineWidth', 1.5); hold on;
d2m = yline(Cl_medio2, 'c--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

d3 = plot(time3, Cl3, 'm', 'LineWidth', 1.5); hold on;
d3m = yline(Cl_medio3, 'y--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

legend ([d1, d1m, d2, d2m, d3, d3m], {'Cl Malla Fina', 'Cl Medio Malla Fina', 'Cl Malla Media', 'Cl Medio Malla Media', 'Cl Malla gruesa', 'Cl Medio Malla Gruesa'}, 'Location', 'best');
title('Evolucion Temporal del Coeficiente de Sustentacion (Cl)');
xlabel('Tiempo (s)', 'Fontsize', 15);
ylabel ('Cl', 'Fontsize', 15); 
grid on;

subplot(2,1,2);
f1 = plot(time1, Cd1, 'k', 'LineWidth', 1.5); hold on;
f1m = yline(Cd_medio, 'r--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

f2 = plot(time2, Cd2, 'g', 'LineWidth', 1.5); hold on;
f2m = yline(Cd_medio2, 'b--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

f3 = plot(time3, Cd3, 'm', 'LineWidth', 1.5); hold on;
f3m = yline(Cd_medio3, 'y--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);

legend ([f1, f1m, f2, f2m, f3, f3m], {'Cd Malla Fina', 'Cd Medio Malla Fina', 'Cd Malla Media', 'Cd Medio Malla Media', 'Cd Malla gruesa', 'Cd Medio Malla Gruesa'}, 'Location', 'best');

title('Evolucion Temporal del Coeficiente de Resistencia (Cd)');
xlabel('Tiempo (s)', 'Fontsize', 15);
ylabel ('Cd', 'Fontsize', 15); grid on;

fprintf('Resultados promediados desde t = %.1f s:\n', t_inicio);
fprintf('Cl medio: %.4f\n', Cl_medio);
fprintf('Cd medio: %.4f\n', Cd_medio);
fprintf('Cl medio2: %.4f\n', Cl_medio2);
fprintf('Cd medio2: %.4f\n', Cd_medio2);
fprintf('Cl medio3: %.4f\n', Cl_medio3);
fprintf('Cd medio3: %.4f\n', Cd_medio3);


%Analisis del valor estacionario

segundos_objetivo = 0:10; %Crea el vector de segundos quitando el 0

indices_enteros = [];
indices_enteros2 = [];
indices_enteros3 = [];

for s = segundos_objetivo

    [val, idx] = min(abs(time1 - s));

    if val < 0.05
        indices_enteros = [indices_enteros; idx];
    end
end

for s2 = segundos_objetivo

    [val2, idx2] = min(abs(time2 - s2));

    if val2 < 0.05
        indices_enteros2 = [indices_enteros2; idx2];
    end
end

for s3 = segundos_objetivo

    [val3, idx3] = min(abs(time3 - s3));

    if val3 < 0.05
        indices_enteros3 = [indices_enteros3; idx3];
    end
end

tiempo_filtrado = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10];

t = 0;
indices_enteros = [];

for i = 1:length(time1)

    if t == 0
        if time1(i) >= 1.0
            t = 1;
            indices_enteros = [indices_enteros; i];
        end
    else


        if time1(i) >= (t + 1) && t <=10
            t = t + 1;
            indices_enteros = [indices_enteros; i];
        end
    end
end

t2 = 0;
indices_enteros2 = [];

for j = 1:length(time2)

    if t2 == 0
        if time2(j) >= 1.0
            t2 = 1;
            indices_enteros2 = [indices_enteros2; j];
        end
    else


        if time2(j) >= (t2 + 1) && t2 <=10
            t2 = t2 + 1;
            indices_enteros2 = [indices_enteros2; j];
        end
    end
end

t3 = 0;
indices_enteros3 = [];

for k = 1:length(time3)

    if t3 == 0
        if time3(k) >= 1.0
            t3 = 1;
            indices_enteros3 = [indices_enteros3; k];
        end
    else


        if time3(k) >= (t3 + 1) && t3 <=10
            t3 = t3 + 1;
            indices_enteros3 = [indices_enteros3; k];
        end
    end
end


Cd_filtrado   = Cd1(indices_enteros);
Cl_filtrado   = Cl1(indices_enteros);

Cd_filtrado2   = Cd2(indices_enteros2);
Cl_filtrado2   = Cl2(indices_enteros2);

Cd_filtrado3   = Cd3(indices_enteros3);
Cl_filtrado3   = Cl3(indices_enteros3);


%Se representa los coeficientes
figure('Color', 'w', 'Name', 'Validacion de Puntos Enteros');
hold on;

a1 = plot(tiempo_filtrado, Cl_filtrado, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
a2 = plot(tiempo_filtrado, Cl_filtrado2, 'cx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
a3 = plot(tiempo_filtrado, Cl_filtrado3, 'mx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
legend ([a1, a2, a3], {'Cl Malla Fina', 'Cl Malla Media', 'Cl Malla gruesa'}, 'Location', 'best');

title('Coeficiente de Sustentacion (C_l) cada segundo');
xlabel('Tiempo (s)', 'Fontsize', 15.5);
ylabel ('C_l', 'Fontsize', 15.5);
grid on;

figure('Color', 'w', 'Name', 'Validacion de Puntos EnterosCd');
hold on;

b1 = plot(tiempo_filtrado, Cd_filtrado, 'kx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
b2 = plot(tiempo_filtrado, Cd_filtrado2, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
b3 = plot(tiempo_filtrado, Cd_filtrado3, 'gx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
legend ([b1, b2, b3], {'Cd Malla Fina', 'Cd Malla Media', 'Cd Malla gruesa'}, 'Location', 'best');

title('Coeficiente de Resistencia (C_d) cada segundo');
xlabel('Tiempo (s)', 'Fontsize', 15.5);
ylabel ('C_d', 'Fontsize', 15.5);
grid on;
