#!/bin/bash

#------- DIRECTIVAS SBATCH -------
# Datos genericos aplicables a todos los trabajos:
#SBATCH --partition=normal
#SBATCH --mail-user=pablo.arizacal@alum.uca.es
#SBATCH --mail-type=BEGIN,FAIL,TIME_LIMIT_90,END
#SBATCH --requeue

# Descripcion del trabajo:
#SBATCH --job-name="DNS"
#SBATCH --comment="Independencia malla"

# *** MUY IMPORTANTE ***
#SBATCH --tasks=1
#SBATCH --cpus-per-task=32
#SBATCH --nodes=1
#SBATCH --time=10-00:00:00

#------- CONFIGURACION ENTORNO -------
module load OpenFOAM/v2212

#------- EJECUTAMOS EL PROGRAMA -------
srun ./Allrun

#------- FIN -------
exit $RESULT
