%Script para representar los coeficientes aerodinamicos obtenido de las simulaciones
clear;
close all;
clc;
%Se cargan los datos
data1000 = importdata('momento24grados.dat');

raw_data1000 = data1000.data;


%Se cargan las columnas con los respectivos coeficientes
time1000 = raw_data1000(:, 1);
Cm1000 = 2*raw_data1000(:, 4)/(1.225*1*1^2*1);


%Se establece el tiempo para calcular el promedio
t_inicio = 7;
indices_estables1000 = find(time1000 >= t_inicio);

Cm_medio1000 = mean(Cm1000(indices_estables1000));

%Se representa los coeficientes
figure('Color', 'w');
hold on;
subplot(2,1,1);
d1 = plot(time1000, Cm1000, 'b', 'LineWidth', 1.5); hold on;
d1m = yline(Cm_medio1000, 'r--', 'LineWidth', 2);
set(gca, 'Fontsize', 13);


legend ([d1, d1m], {'Cm 5 grados', 'Cm Medio 5 grados'}, 'Location', 'best');
title('Evolucion Temporal del Coeficiente de momento de cabeceo (Cm)');
xlabel('Tiempo (s)', 'Fontsize', 15);
ylabel ('Cm', 'Fontsize', 15); 
grid on;

fprintf('Resultados promediados desde t = %.1f s:\n', t_inicio);
fprintf('Cm medio 5 grados: %.4f\n', Cm_medio1000);



%Analisis del valor estacionario

segundos_objetivo = 0:15; %Crea el vector de segundos quitando el 0

indices_enteros1000 = [];

for s1000 = segundos_objetivo

    [val1000, idx1000] = min(abs(time1000 - s1000));

    if val1000 < 0.05
        indices_enteros1000 = [indices_enteros1000; idx1000];
    end
end


tiempo_filtrado = [1; 2; 3; 4; 5; 6; 7; 8; 9; 10; 11; 12; 13; 14; 15];

t1000 = 0;
indices_enteros1000 = [];

for i = 1:length(time1000)

    if t1000 == 0
        if time1000(i) >= 1.0
            t1000 = 1;
            indices_enteros1000 = [indices_enteros1000; i];
        end
    else


        if time1000(i) >= (t1000 + 1) && t1000 <=15
            t1000 = t1000 + 1;
            indices_enteros1000 = [indices_enteros1000; i];
        end
    end
end

Cm_filtrado1000   = Cm1000(indices_enteros1000);

%Se representa los coeficientes
figure('Color', 'w', 'Name', 'Validacion de Puntos Enteros');
hold on;

a1 = plot(tiempo_filtrado, Cm_filtrado1000, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
set(gca, 'Fontsize', 14);
legend ([a1], {'Cm 12 grados'}, 'Location', 'best');

title('Coeficiente de momento de cabeceo (C_m) cada segundo');
xlabel('Tiempo (s)', 'Fontsize', 15.5);
ylabel ('C_m', 'Fontsize', 15.5);
grid on;